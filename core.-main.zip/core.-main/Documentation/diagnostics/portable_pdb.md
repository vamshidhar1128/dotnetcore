# File has moved

This document has moved to <https://github.com/dotnet/designs/blob/main/accepted/2020/diagnostics/portable-pdb.md>
