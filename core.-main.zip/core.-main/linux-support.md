# .NET Support and Compatibility for Linux Distributions

This content has been moved to [linux.md](linux.md).
