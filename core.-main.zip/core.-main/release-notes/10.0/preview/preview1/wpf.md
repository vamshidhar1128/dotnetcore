# WPF in .NET 10 Preview 1 - Release Notes

This release was focused on quality improvements to WPF. You can find detailed information about the improvements in the GitHub Release below:

- [WPF GitHub Release Notes](https://github.com/dotnet/wpf/releases/tag/v10.0.0-preview.1.25080.3)

WPF updates in .NET 10:

- [What's new in WPF in .NET 10](https://learn.microsoft.com/dotnet/desktop/wpf/whats-new/net100) documentation
