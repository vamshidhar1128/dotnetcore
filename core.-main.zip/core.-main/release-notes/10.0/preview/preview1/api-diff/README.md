# .NET 10.0 Preview 1 API Changes

The following API changes were made in .NET 10.0 Preview 1:

- [Microsoft.NETCore.App](./Microsoft.NETCore.App/10.0-preview1.md)
- [Microsoft.AspNetCore.App](./Microsoft.AspNetCore.App/10.0-preview1.md)
- [Microsoft.WindowsDesktop.App](./Microsoft.WindowsDesktop.App/10.0-preview1.md)
