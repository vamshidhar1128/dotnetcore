# Visual Basic updates in .NET 10 Preview 2 - Release Notes

This preview release does not contain new Visual Basic features. Please checkout the lastest documentation:

- [What's new in Visual Basic](https://learn.microsoft.com/dotnet/visual-basic/whats-new/) documentation
- [Breaking changes](https://learn.microsoft.com/dotnet/visual-basic/whats-new/breaking-changes)
