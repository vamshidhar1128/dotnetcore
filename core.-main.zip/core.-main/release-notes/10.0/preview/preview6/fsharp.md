# F# updates in .NET 10 Preview 6 - Release Notes

This preview release does not contain new F# features. View the [What's new in F#](https://fsharp.github.io/fsharp-compiler-docs/release-notes/Language.html) documentation to learn more.
