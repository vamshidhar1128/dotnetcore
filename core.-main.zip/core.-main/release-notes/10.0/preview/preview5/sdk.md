# .NET SDK in .NET 10 Preview 5 - Release Notes

This preview release does not contain new SDK features.
