# Container image updates in .NET 10 Preview 4 - Release Notes

This preview release does not contain new Container image features.
