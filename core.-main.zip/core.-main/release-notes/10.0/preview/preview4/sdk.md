# .NET SDK in .NET 10 Preview 4 - Release Notes

This preview release does not contain new SDK features.

.NET SDK updates in .NET 10:

- [What's new in .NET 10](https://learn.microsoft.com/dotnet/core/whats-new/dotnet-10/overview) documentation
