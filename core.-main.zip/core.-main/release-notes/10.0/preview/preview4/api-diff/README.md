# .NET 10.0 Preview 4 API Changes

The following API changes were made in .NET 10.0 Preview 4:

- [Microsoft.NETCore.App](./Microsoft.NETCore.App/10.0-preview4.md)
- [Microsoft.AspNetCore.App](./Microsoft.AspNetCore.App/10.0-preview4.md)
- [Microsoft.WindowsDesktop.App](./Microsoft.WindowsDesktop.App/10.0-preview4.md)
