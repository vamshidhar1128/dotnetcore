# .NET 10.0 Preview 3 API Changes

The following API changes were made in .NET 10.0 Preview 3:

- [Microsoft.NETCore.App](./Microsoft.NETCore.App/10.0-preview3.md)
- [Microsoft.AspNetCore.App](./Microsoft.AspNetCore.App/10.0-preview3.md)
- [Microsoft.WindowsDesktop.App](./Microsoft.WindowsDesktop.App/10.0-preview3.md)
