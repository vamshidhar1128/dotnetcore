# Container image updates in .NET 10 Preview 3 - Release Notes

This preview release does not contain new Container image features.
