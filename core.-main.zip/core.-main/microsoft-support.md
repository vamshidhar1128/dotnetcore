# Microsoft support for .NET

This content has been moved to [.NET support](support.md).
