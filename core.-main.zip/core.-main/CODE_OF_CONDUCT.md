# Code of Conduct

This project uses the [.NET Foundation Code of Conduct](https://dotnetfoundation.org/code-of-conduct) to define expected conduct in our community.
Instances of abusive, harassing, or otherwise unacceptable behavior may be reported by contacting a project maintainer at <conduct@dotnetfoundation.org>.
